"""
Unit tests for portfolio analytics functions.

Run with:  pytest test_analytics.py -v
"""

import numpy as np
import pandas as pd
import pytest

from analytics import (
    annualized_return,
    annualized_vol,
    sharpe_ratio,
    sortino_ratio,
    max_drawdown,
    var_historic,
    cvar_historic,
    compute_cumulative,
    compute_drawdown,
    compute_portfolio_returns,
    portfolio_stats,
)


# ──────────────────────────────────────────────
# Fixtures
# ──────────────────────────────────────────────
@pytest.fixture
def constant_returns():
    """Daily returns of exactly +0.1% every day for 252 days."""
    return pd.Series([0.001] * 252)


@pytest.fixture
def zero_returns():
    """Zero returns."""
    return pd.Series([0.0] * 252)


@pytest.fixture
def known_returns():
    """Simple alternating returns for predictable stats."""
    np.random.seed(42)
    return pd.Series(np.random.normal(0.0004, 0.01, 504))


@pytest.fixture
def simple_prices():
    """Two-asset price dataframe for testing portfolio construction."""
    dates = pd.date_range("2023-01-01", periods=6, freq="B")
    return pd.DataFrame(
        {"A": [100, 102, 101, 105, 103, 107], "B": [50, 51, 49, 52, 50, 53]},
        index=dates,
    )


# ──────────────────────────────────────────────
# Tests: annualized_return
# ──────────────────────────────────────────────
class TestAnnualizedReturn:
    def test_constant_positive(self, constant_returns):
        """0.1% daily for 252 days ≈ 28.6% annualized."""
        result = annualized_return(constant_returns, periods=252)
        expected = (1.001) ** 252 - 1  # ~28.6%
        assert abs(result - expected) < 1e-6

    def test_zero_returns(self, zero_returns):
        result = annualized_return(zero_returns)
        assert abs(result) < 1e-10

    def test_single_day(self):
        ret = pd.Series([0.05])
        result = annualized_return(ret, periods=252)
        expected = (1.05) ** 252 - 1
        assert abs(result - expected) < 1e-4


# ──────────────────────────────────────────────
# Tests: annualized_vol
# ──────────────────────────────────────────────
class TestAnnualizedVol:
    def test_constant_returns_zero_vol(self, constant_returns):
        """Constant returns should have zero volatility."""
        result = annualized_vol(constant_returns)
        assert abs(result) < 1e-10

    def test_known_vol(self):
        """Manually computed volatility check."""
        returns = pd.Series([0.01, -0.01, 0.01, -0.01])
        daily_std = returns.std()
        expected = daily_std * np.sqrt(252)
        result = annualized_vol(returns)
        assert abs(result - expected) < 1e-10

    def test_positive(self, known_returns):
        result = annualized_vol(known_returns)
        assert result > 0


# ──────────────────────────────────────────────
# Tests: sharpe_ratio
# ──────────────────────────────────────────────
class TestSharpeRatio:
    def test_zero_vol_returns_zero(self, constant_returns):
        """Constant returns have near-zero vol → extremely high Sharpe (edge case)."""
        result = sharpe_ratio(constant_returns, rf=0.0)
        # With constant returns, std ≈ 0 (floating point), so Sharpe blows up.
        # This is expected behavior — in practice, truly constant returns don't exist.
        assert result > 1000  # effectively infinite

    def test_higher_return_higher_sharpe(self):
        """Portfolio A with higher return should have higher Sharpe than B."""
        np.random.seed(1)
        ret_a = pd.Series(np.random.normal(0.001, 0.01, 252))
        ret_b = pd.Series(np.random.normal(0.0001, 0.01, 252))
        sharpe_a = sharpe_ratio(ret_a, rf=0.0)
        sharpe_b = sharpe_ratio(ret_b, rf=0.0)
        assert sharpe_a > sharpe_b

    def test_risk_free_impact(self, known_returns):
        """Higher risk-free rate → lower Sharpe."""
        sr_low = sharpe_ratio(known_returns, rf=0.01)
        sr_high = sharpe_ratio(known_returns, rf=0.10)
        assert sr_low > sr_high


# ──────────────────────────────────────────────
# Tests: sortino_ratio
# ──────────────────────────────────────────────
class TestSortinoRatio:
    def test_all_positive_returns(self):
        """If all returns are positive, downside std is 0 → returns 0."""
        ret = pd.Series([0.01, 0.02, 0.005, 0.015])
        result = sortino_ratio(ret, rf=0.0)
        assert result == 0.0

    def test_sortino_ge_sharpe(self, known_returns):
        """Sortino should be ≥ Sharpe when there's asymmetric downside."""
        sr = sharpe_ratio(known_returns, rf=0.0)
        so = sortino_ratio(known_returns, rf=0.0)
        # Sortino uses only downside deviation, so it should be ≥ Sharpe
        assert so >= sr - 0.5  # generous tolerance for random data


# ──────────────────────────────────────────────
# Tests: max_drawdown
# ──────────────────────────────────────────────
class TestMaxDrawdown:
    def test_always_positive(self):
        """If prices only go up, max drawdown is 0."""
        ret = pd.Series([0.01, 0.02, 0.01, 0.03])
        result = max_drawdown(ret)
        assert abs(result) < 1e-10

    def test_known_drawdown(self):
        """50% drop: wealth goes 1 → 1.1 → 0.55 → should be ~50%."""
        ret = pd.Series([0.10, -0.50])
        result = max_drawdown(ret)
        # Wealth: 1.0 → 1.1 → 0.55. Peak=1.1, DD = (0.55-1.1)/1.1 = -0.5
        assert abs(result - (-0.5)) < 1e-10

    def test_negative_value(self, known_returns):
        """Max drawdown should always be ≤ 0."""
        result = max_drawdown(known_returns)
        assert result <= 0


# ──────────────────────────────────────────────
# Tests: VaR and CVaR
# ──────────────────────────────────────────────
class TestVaRCVaR:
    def test_var_is_negative(self, known_returns):
        """VaR at 95% should typically be negative for realistic returns."""
        result = var_historic(known_returns)
        assert result < 0

    def test_cvar_le_var(self, known_returns):
        """CVaR should be worse (more negative) than VaR."""
        var = var_historic(known_returns)
        cvar = cvar_historic(known_returns)
        assert cvar <= var

    def test_var_percentile(self):
        """VaR at 95% should be the 5th percentile."""
        returns = pd.Series(np.arange(-100, 0) / 1000)  # -10% to 0%
        var = var_historic(returns, confidence=0.95)
        expected = np.percentile(returns, 5)
        assert abs(var - expected) < 1e-10


# ──────────────────────────────────────────────
# Tests: compute_cumulative
# ──────────────────────────────────────────────
class TestCumulative:
    def test_zero_returns(self, zero_returns):
        cum = compute_cumulative(zero_returns)
        assert np.allclose(cum.values, 0.0)

    def test_known_cumulative(self):
        ret = pd.Series([0.10, 0.10])
        cum = compute_cumulative(ret)
        assert abs(cum.iloc[-1] - 0.21) < 1e-10  # 1.1 * 1.1 - 1 = 0.21


# ──────────────────────────────────────────────
# Tests: compute_drawdown
# ──────────────────────────────────────────────
class TestDrawdown:
    def test_no_drawdown_uptrend(self):
        ret = pd.Series([0.01, 0.02, 0.01])
        dd = compute_drawdown(ret)
        assert all(dd >= -1e-10)

    def test_drawdown_after_peak(self):
        ret = pd.Series([0.10, -0.20, 0.05])
        dd = compute_drawdown(ret)
        assert dd.min() < 0


# ──────────────────────────────────────────────
# Tests: portfolio construction
# ──────────────────────────────────────────────
class TestPortfolioReturns:
    def test_equal_weight(self, simple_prices):
        weights = {"A": 0.5, "B": 0.5}
        port_ret = compute_portfolio_returns(simple_prices, weights)
        asset_rets = simple_prices.pct_change().dropna()
        expected = asset_rets["A"] * 0.5 + asset_rets["B"] * 0.5
        assert np.allclose(port_ret.values, expected.values, atol=1e-10)

    def test_single_asset(self, simple_prices):
        weights = {"A": 1.0, "B": 0.0}
        port_ret = compute_portfolio_returns(simple_prices, weights)
        asset_rets = simple_prices.pct_change().dropna()
        assert np.allclose(port_ret.values, asset_rets["A"].values, atol=1e-10)


# ──────────────────────────────────────────────
# Tests: portfolio_stats (for efficient frontier)
# ──────────────────────────────────────────────
class TestPortfolioStats:
    def test_single_asset(self):
        """Single asset: portfolio stats should match individual stats."""
        mean_rets = np.array([0.001])
        cov = np.array([[0.0004]])
        weights = np.array([1.0])
        ret, vol, sr = portfolio_stats(weights, mean_rets, cov, rf=0.0)
        assert abs(ret - 0.001 * 252) < 1e-6
        assert abs(vol - np.sqrt(0.0004 * 252)) < 1e-6

    def test_weights_sum_check(self):
        """Diversification should reduce vol vs individual assets."""
        mean_rets = np.array([0.001, 0.001])
        # Low correlation
        cov = np.array([[0.0004, 0.00005], [0.00005, 0.0004]])
        equal_w = np.array([0.5, 0.5])
        _, vol_eq, _ = portfolio_stats(equal_w, mean_rets, cov, rf=0.0)
        single_w = np.array([1.0, 0.0])
        _, vol_single, _ = portfolio_stats(single_w, mean_rets, cov, rf=0.0)
        assert vol_eq < vol_single  # diversification benefit


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
