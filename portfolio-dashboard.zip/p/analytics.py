"""
analytics.py — Pure analytics functions for portfolio analysis.

No Streamlit dependency — importable for testing and reuse.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from scipy.optimize import minimize


# ──────────────────────────────────────────────
# Core Portfolio Analytics
# ──────────────────────────────────────────────
def compute_portfolio_returns(
    prices: pd.DataFrame, weights: Dict[str, float]
) -> pd.Series:
    """Compute weighted portfolio daily returns."""
    returns = prices.pct_change().dropna()
    w = np.array([weights[t] for t in prices.columns])
    port_returns = returns.dot(w)
    port_returns.name = "Portfolio"
    return port_returns


def compute_cumulative(returns: pd.Series) -> pd.Series:
    """Compute cumulative return series from daily returns."""
    return (1 + returns).cumprod() - 1


def compute_drawdown(returns: pd.Series) -> pd.Series:
    """Compute drawdown series (underwater chart)."""
    wealth = (1 + returns).cumprod()
    running_max = wealth.cummax()
    return (wealth - running_max) / running_max


def annualized_return(returns: pd.Series, periods: int = 252) -> float:
    """Compute annualized return from daily returns."""
    total = (1 + returns).prod()
    n_years = len(returns) / periods
    return total ** (1 / n_years) - 1 if n_years > 0 else 0.0


def annualized_vol(returns: pd.Series, periods: int = 252) -> float:
    """Compute annualized volatility from daily returns."""
    return returns.std() * np.sqrt(periods)


def sharpe_ratio(returns: pd.Series, rf: float = 0.04, periods: int = 252) -> float:
    """Compute annualized Sharpe ratio."""
    ann_ret = annualized_return(returns, periods)
    ann_vol = annualized_vol(returns, periods)
    return (ann_ret - rf) / ann_vol if ann_vol > 0 else 0.0


def sortino_ratio(returns: pd.Series, rf: float = 0.04, periods: int = 252) -> float:
    """Compute annualized Sortino ratio (downside deviation only)."""
    ann_ret = annualized_return(returns, periods)
    downside = returns[returns < 0].std() * np.sqrt(periods)
    return (ann_ret - rf) / downside if downside > 0 else 0.0


def max_drawdown(returns: pd.Series) -> float:
    """Compute maximum drawdown from daily returns."""
    dd = compute_drawdown(returns)
    return dd.min()


def var_historic(returns: pd.Series, confidence: float = 0.95) -> float:
    """Compute historical Value-at-Risk at given confidence level."""
    return np.percentile(returns, (1 - confidence) * 100)


def cvar_historic(returns: pd.Series, confidence: float = 0.95) -> float:
    """Compute Conditional VaR (Expected Shortfall) at given confidence level."""
    var = var_historic(returns, confidence)
    return returns[returns <= var].mean()


def monte_carlo_simulation(
    returns: pd.Series, days: int = 252, n_sims: int = 1000
) -> np.ndarray:
    """Run Monte Carlo simulation of future portfolio paths.
    
    Args:
        returns: Historical daily returns to calibrate mu/sigma.
        days: Number of trading days to simulate forward.
        n_sims: Number of simulation paths.
    
    Returns:
        Array of shape (days, n_sims) with cumulative wealth paths starting at $1.
    """
    mu = returns.mean()
    sigma = returns.std()
    sims = np.zeros((days, n_sims))
    for i in range(n_sims):
        daily_returns = np.random.normal(mu, sigma, days)
        sims[:, i] = np.cumprod(1 + daily_returns)
    return sims


# ──────────────────────────────────────────────
# Efficient Frontier
# ──────────────────────────────────────────────
def portfolio_stats(
    weights: np.ndarray, mean_returns: np.ndarray, cov_matrix: np.ndarray,
    rf: float = 0.04, periods: int = 252,
) -> Tuple[float, float, float]:
    """Return (annualized return, annualized vol, Sharpe) for a given weight vector."""
    port_ret = np.dot(weights, mean_returns) * periods
    port_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix * periods, weights)))
    port_sharpe = (port_ret - rf) / port_vol if port_vol > 0 else 0.0
    return port_ret, port_vol, port_sharpe


def neg_sharpe(
    weights: np.ndarray, mean_returns: np.ndarray, cov_matrix: np.ndarray,
    rf: float = 0.04, periods: int = 252,
) -> float:
    """Objective: negative Sharpe ratio (for minimization)."""
    _, _, sr = portfolio_stats(weights, mean_returns, cov_matrix, rf, periods)
    return -sr


def min_variance_obj(
    weights: np.ndarray, cov_matrix: np.ndarray, periods: int = 252,
) -> float:
    """Objective: portfolio variance."""
    return np.dot(weights.T, np.dot(cov_matrix * periods, weights))


def compute_efficient_frontier(
    returns_df: pd.DataFrame, rf: float = 0.04, n_points: int = 80, n_random: int = 5000,
) -> Dict:
    """
    Compute the efficient frontier, max-Sharpe portfolio, and min-variance portfolio.
    
    Args:
        returns_df: DataFrame of daily asset returns (each column = one asset).
        rf: Annual risk-free rate.
        n_points: Number of points on the efficient frontier curve.
        n_random: Number of random portfolios to generate for the scatter cloud.
    
    Returns:
        Dict with keys: tickers, max_sharpe_w, ms_ret, ms_vol, ms_sharpe,
        min_var_w, mv_ret, mv_vol, mv_sharpe, rand_rets, rand_vols, rand_sharpes,
        frontier_rets, frontier_vols.
    """
    mean_returns = returns_df.mean().values
    cov_matrix = returns_df.cov().values
    n_assets = len(mean_returns)
    tickers = list(returns_df.columns)

    constraints = {"type": "eq", "fun": lambda w: np.sum(w) - 1}
    bounds = tuple((0.0, 1.0) for _ in range(n_assets))
    init_w = np.array([1.0 / n_assets] * n_assets)

    # Max Sharpe portfolio
    max_sharpe_res = minimize(
        neg_sharpe, init_w, args=(mean_returns, cov_matrix, rf),
        method="SLSQP", bounds=bounds, constraints=constraints,
    )
    ms_ret, ms_vol, ms_sharpe = portfolio_stats(max_sharpe_res.x, mean_returns, cov_matrix, rf)

    # Min Variance portfolio
    min_var_res = minimize(
        min_variance_obj, init_w, args=(cov_matrix,),
        method="SLSQP", bounds=bounds, constraints=constraints,
    )
    mv_ret, mv_vol, mv_sharpe = portfolio_stats(min_var_res.x, mean_returns, cov_matrix, rf)

    # Random portfolios
    rand_rets, rand_vols, rand_sharpes = [], [], []
    for _ in range(n_random):
        w = np.random.dirichlet(np.ones(n_assets))
        r, v, s = portfolio_stats(w, mean_returns, cov_matrix, rf)
        rand_rets.append(r)
        rand_vols.append(v)
        rand_sharpes.append(s)

    # Efficient frontier curve
    target_returns = np.linspace(mv_ret, max(rand_rets) * 0.95, n_points)
    frontier_vols = []
    for target in target_returns:
        cons = [
            {"type": "eq", "fun": lambda w: np.sum(w) - 1},
            {"type": "eq", "fun": lambda w, t=target: np.dot(w, mean_returns) * 252 - t},
        ]
        res = minimize(min_variance_obj, init_w, args=(cov_matrix,),
                       method="SLSQP", bounds=bounds, constraints=cons)
        frontier_vols.append(np.sqrt(res.fun) if res.success else np.nan)

    return {
        "tickers": tickers,
        "max_sharpe_w": max_sharpe_res.x,
        "ms_ret": ms_ret, "ms_vol": ms_vol, "ms_sharpe": ms_sharpe,
        "min_var_w": min_var_res.x,
        "mv_ret": mv_ret, "mv_vol": mv_vol, "mv_sharpe": mv_sharpe,
        "rand_rets": rand_rets, "rand_vols": rand_vols, "rand_sharpes": rand_sharpes,
        "frontier_rets": target_returns.tolist(), "frontier_vols": frontier_vols,
    }


# ──────────────────────────────────────────────
# Factor Analysis
# ──────────────────────────────────────────────
def run_factor_regression(
    portfolio_returns: pd.Series, factors: pd.DataFrame
) -> Dict:
    """
    Run OLS regression of portfolio excess returns on Fama-French 3 factors.
    
    Args:
        portfolio_returns: Daily portfolio returns.
        factors: DataFrame with columns Mkt-RF, SMB, HML, RF.
    
    Returns:
        Dict with regression results: coefficients, t-stats, p-values,
        R², residuals, annualized alpha, and factor contributions.
    """
    import statsmodels.api as sm

    common = portfolio_returns.index.intersection(factors.index)
    y = portfolio_returns.loc[common] - factors.loc[common, "RF"]
    X = factors.loc[common, ["Mkt-RF", "SMB", "HML"]]
    X = sm.add_constant(X)

    model = sm.OLS(y.values, X.values).fit()

    coef_names = ["Alpha (daily)", "Mkt-RF (β_mkt)", "SMB (β_smb)", "HML (β_hml)"]
    results = {
        "coefficients": dict(zip(coef_names, model.params)),
        "t_stats": dict(zip(coef_names, model.tvalues)),
        "p_values": dict(zip(coef_names, model.pvalues)),
        "r_squared": model.rsquared,
        "adj_r_squared": model.rsquared_adj,
        "residuals": model.resid,
        "fitted": model.fittedvalues,
        "y": y,
        "X": X,
        "factor_names": ["Mkt-RF", "SMB", "HML"],
    }

    daily_alpha = model.params[0]
    results["annualized_alpha"] = (1 + daily_alpha) ** 252 - 1

    mean_factors = X.mean().values
    contributions = model.params * mean_factors * 252
    results["contributions"] = dict(zip(
        ["Alpha", "Market", "Size (SMB)", "Value (HML)"],
        contributions,
    ))

    return results
