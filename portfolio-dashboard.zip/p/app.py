"""
Portfolio Analytics Dashboard
Built with Streamlit

Features:
- Multi-asset portfolio construction with custom weights
- Historical performance & benchmark comparison
- Risk metrics: Sharpe, Sortino, Max Drawdown, VaR, CVaR
- Correlation heatmap & rolling statistics
- Monte Carlo forward simulation
- Efficient Frontier with optimal portfolios (Max Sharpe, Min Variance)
- Fama-French 3-Factor regression & attribution
"""

import streamlit as st
import pandas as pd
import numpy as np
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
from typing import Dict, List, Tuple

from analytics import (
    compute_portfolio_returns, compute_cumulative, compute_drawdown,
    annualized_return, annualized_vol, sharpe_ratio, sortino_ratio,
    max_drawdown, var_historic, cvar_historic, monte_carlo_simulation,
    portfolio_stats, compute_efficient_frontier, run_factor_regression,
)

# ──────────────────────────────────────────────
# Page Config
# ──────────────────────────────────────────────
st.set_page_config(
    page_title="Portfolio Analytics",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ──────────────────────────────────────────────
# Custom CSS
# ──────────────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&family=JetBrains+Mono:wght@400;500&display=swap');

    /* Global */
    .stApp { font-family: 'DM Sans', sans-serif; }

    /* Metric cards */
    div[data-testid="stMetric"] {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        border: 1px solid rgba(255,255,255,0.06);
        border-radius: 12px;
        padding: 16px 20px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.15);
    }
    div[data-testid="stMetric"] label {
        color: #8892b0 !important;
        font-size: 0.8rem !important;
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }
    div[data-testid="stMetric"] [data-testid="stMetricValue"] {
        font-family: 'JetBrains Mono', monospace !important;
        color: #e6f1ff !important;
        font-size: 1.5rem !important;
    }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background: linear-gradient(180deg, #0a0a1a 0%, #111127 100%);
        border-right: 1px solid rgba(255,255,255,0.04);
    }
    section[data-testid="stSidebar"] .stMarkdown h1,
    section[data-testid="stSidebar"] .stMarkdown h2,
    section[data-testid="stSidebar"] .stMarkdown h3 {
        color: #ccd6f6 !important;
    }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
    }
    .stTabs [data-baseweb="tab"] {
        border-radius: 8px;
        padding: 8px 20px;
        font-weight: 500;
    }

    /* Header styling */
    .dashboard-header {
        padding: 1rem 0 0.5rem 0;
        margin-bottom: 1rem;
    }
    .dashboard-header h1 {
        font-family: 'DM Sans', sans-serif;
        font-weight: 700;
        font-size: 2rem;
        color: #ccd6f6;
        margin: 0;
    }
    .dashboard-header p {
        color: #8892b0;
        font-size: 0.95rem;
        margin: 4px 0 0 0;
    }
</style>
""", unsafe_allow_html=True)


# ──────────────────────────────────────────────
# Data Fetching (cached)
# ──────────────────────────────────────────────
@st.cache_data(ttl=3600, show_spinner=False)
def fetch_prices(tickers: List[str], start: str, end: str) -> pd.DataFrame:
    """Download adjusted close prices for a list of tickers."""
    data = yf.download(tickers, start=start, end=end, auto_adjust=True)
    if isinstance(data.columns, pd.MultiIndex):
        prices = data["Close"]
    else:
        prices = data[["Close"]]
        prices.columns = tickers
    return prices.dropna()


@st.cache_data(ttl=3600, show_spinner=False)
def fetch_benchmark(ticker: str, start: str, end: str) -> pd.Series:
    """Download benchmark prices."""
    data = yf.download(ticker, start=start, end=end, auto_adjust=True)
    return data["Close"].dropna()


# ──────────────────────────────────────────────
# Cached wrappers (Streamlit caching for analytics & data)
# ──────────────────────────────────────────────
@st.cache_data(ttl=3600, show_spinner=False)
def cached_efficient_frontier(_returns_df: pd.DataFrame, rf: float = 0.04) -> Dict:
    """Cached wrapper around compute_efficient_frontier."""
    return compute_efficient_frontier(_returns_df, rf=rf)


@st.cache_data(ttl=86400, show_spinner=False)
def fetch_ff_factors(start: str, end: str) -> pd.DataFrame:
    """
    Fetch Fama-French 3-factor proxy data using ETFs.
    Uses: SPY (Mkt), IWM-SPY (SMB), IWD-IWF (HML), SHV (RF proxy).
    """
    proxy_tickers = ["SPY", "IWM", "IWD", "IWF", "SHV"]
    data = yf.download(proxy_tickers, start=start, end=end, auto_adjust=True)
    if isinstance(data.columns, pd.MultiIndex):
        px_data = data["Close"]
    else:
        px_data = data
    px_data = px_data.dropna()
    ret = px_data.pct_change().dropna()

    factors = pd.DataFrame(index=ret.index)
    factors["Mkt-RF"] = ret["SPY"] - ret["SHV"]
    factors["SMB"] = ret["IWM"] - ret["SPY"]
    factors["HML"] = ret["IWD"] - ret["IWF"]
    factors["RF"] = ret["SHV"]
    return factors


# ──────────────────────────────────────────────
# Chart Helpers
# ──────────────────────────────────────────────
PLOTLY_LAYOUT = dict(
    template="plotly_dark",
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="DM Sans, sans-serif", color="#8892b0"),
    title_font=dict(color="#ccd6f6", size=16),
    legend=dict(bgcolor="rgba(0,0,0,0)", font=dict(color="#8892b0")),
    xaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.04)"),
    yaxis=dict(gridcolor="rgba(255,255,255,0.04)", zerolinecolor="rgba(255,255,255,0.04)"),
    margin=dict(l=40, r=20, t=50, b=40),
)

COLORS = ["#64ffda", "#f77fbe", "#ffd700", "#82aaff", "#c792ea", "#ff6b6b", "#5cdb95"]


def styled_fig(fig: go.Figure) -> go.Figure:
    fig.update_layout(**PLOTLY_LAYOUT)
    return fig


# ──────────────────────────────────────────────
# Sidebar — Portfolio Construction
# ──────────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Portfolio Setup")

    # Preset portfolios
    presets = {
        "Custom": {},
        "Classic 60/40": {"SPY": 60, "AGG": 40},
        "Tech Heavy": {"QQQ": 40, "AAPL": 15, "MSFT": 15, "GOOGL": 15, "AMZN": 15},
        "All Weather": {"SPY": 30, "TLT": 40, "GLD": 15, "DBC": 7.5, "IEF": 7.5},
        "Dividend Growth": {"VIG": 30, "SCHD": 30, "HDV": 20, "DGRO": 20},
    }
    preset_choice = st.selectbox("Quick Presets", list(presets.keys()))

    st.markdown("---")
    st.markdown("### Holdings")

    if preset_choice != "Custom":
        default_tickers = list(presets[preset_choice].keys())
        default_weights = list(presets[preset_choice].values())
    else:
        default_tickers = ["AAPL", "MSFT", "GOOGL", "AMZN"]
        default_weights = [25, 25, 25, 25]

    ticker_input = st.text_input(
        "Tickers (comma-separated)",
        value=", ".join(default_tickers),
        help="Enter stock/ETF tickers separated by commas",
    )
    tickers = [t.strip().upper() for t in ticker_input.split(",") if t.strip()]

    st.markdown("#### Weights (%)")
    weights_raw: Dict[str, float] = {}
    cols = st.columns(2)
    for i, ticker in enumerate(tickers):
        default_w = default_weights[i] if i < len(default_weights) else round(100 / len(tickers), 1)
        with cols[i % 2]:
            weights_raw[ticker] = st.number_input(
                ticker, min_value=0.0, max_value=100.0, value=float(default_w), step=1.0, key=f"w_{ticker}"
            )

    total_weight = sum(weights_raw.values())
    if abs(total_weight - 100) > 0.01:
        st.warning(f"Weights sum to {total_weight:.1f}% — they should total 100%.")
    weights = {t: w / 100 for t, w in weights_raw.items()}

    st.markdown("---")
    st.markdown("### Parameters")
    benchmark = st.selectbox("Benchmark", ["SPY", "QQQ", "IWM", "AGG", "^GSPC"], index=0)
    lookback_years = st.slider("Lookback (years)", 1, 10, 3)
    risk_free = st.number_input("Risk-Free Rate (%)", value=4.0, step=0.25) / 100

    end_date = datetime.today()
    start_date = end_date - timedelta(days=lookback_years * 365)

    run = st.button("🚀 Analyze Portfolio", type="primary", use_container_width=True)


# ──────────────────────────────────────────────
# Main Content
# ──────────────────────────────────────────────
st.markdown(
    '<div class="dashboard-header">'
    "<h1>📊 Portfolio Analytics Dashboard</h1>"
    "<p>Real-time portfolio analysis, risk metrics, and Monte Carlo simulation</p>"
    "</div>",
    unsafe_allow_html=True,
)

if not run and "portfolio_returns" not in st.session_state:
    st.info("👈 Configure your portfolio in the sidebar and click **Analyze Portfolio** to begin.")
    st.stop()

# ──────────────────────────────────────────────
# Fetch & Compute
# ──────────────────────────────────────────────
with st.spinner("Fetching market data..."):
    prices = fetch_prices(tickers, start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"))
    bench_prices = fetch_benchmark(benchmark, start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"))

if prices.empty:
    st.error("Could not fetch data for the given tickers. Check symbols and try again.")
    st.stop()

# Align dates
common_idx = prices.index.intersection(bench_prices.index)
prices = prices.loc[common_idx]
bench_prices = bench_prices.loc[common_idx]

port_returns = compute_portfolio_returns(prices, weights)
bench_returns = bench_prices.pct_change().dropna()
port_returns = port_returns.loc[port_returns.index.intersection(bench_returns.index)]
bench_returns = bench_returns.loc[bench_returns.index.intersection(port_returns.index)]

# Store in session state
st.session_state["portfolio_returns"] = port_returns

# ──────────────────────────────────────────────
# KPI Row
# ──────────────────────────────────────────────
k1, k2, k3, k4, k5, k6 = st.columns(6)
ann_ret = annualized_return(port_returns)
ann_v = annualized_vol(port_returns)
sr = sharpe_ratio(port_returns, risk_free)
so = sortino_ratio(port_returns, risk_free)
mdd = max_drawdown(port_returns)
var95 = var_historic(port_returns)

k1.metric("Ann. Return", f"{ann_ret:.2%}")
k2.metric("Ann. Volatility", f"{ann_v:.2%}")
k3.metric("Sharpe Ratio", f"{sr:.2f}")
k4.metric("Sortino Ratio", f"{so:.2f}")
k5.metric("Max Drawdown", f"{mdd:.2%}")
k6.metric("Daily VaR (95%)", f"{var95:.2%}")

# ──────────────────────────────────────────────
# Tabs
# ──────────────────────────────────────────────
tab_perf, tab_risk, tab_corr, tab_mc, tab_ef, tab_factor = st.tabs(
    ["📈 Performance", "⚠️ Risk Analysis", "🔗 Correlations", "🎲 Monte Carlo",
     "🎯 Efficient Frontier", "🔬 Factor Analysis"]
)

# ── TAB 1: Performance ──
with tab_perf:
    col1, col2 = st.columns([2, 1])

    with col1:
        cum_port = compute_cumulative(port_returns)
        cum_bench = compute_cumulative(bench_returns)

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=cum_port.index, y=cum_port.values,
            name="Portfolio", line=dict(color=COLORS[0], width=2.5),
            fill="tozeroy", fillcolor="rgba(100,255,218,0.08)",
        ))
        fig.add_trace(go.Scatter(
            x=cum_bench.index, y=cum_bench.values,
            name=benchmark, line=dict(color=COLORS[1], width=2, dash="dot"),
        ))
        fig.update_layout(
            title="Cumulative Returns vs Benchmark",
            yaxis_title="Cumulative Return",
            yaxis_tickformat=".0%",
            hovermode="x unified",
        )
        st.plotly_chart(styled_fig(fig), use_container_width=True)

    with col2:
        # Weight pie
        fig_pie = go.Figure(data=[go.Pie(
            labels=list(weights.keys()),
            values=[w * 100 for w in weights.values()],
            hole=0.55,
            marker=dict(colors=COLORS[: len(weights)]),
            textinfo="label+percent",
            textfont=dict(color="#ccd6f6", size=12),
        )])
        fig_pie.update_layout(
            title="Portfolio Allocation",
            showlegend=False,
            height=380,
        )
        st.plotly_chart(styled_fig(fig_pie), use_container_width=True)

    # Rolling returns
    st.markdown("#### Rolling 60-Day Returns")
    rolling_port = port_returns.rolling(60).apply(lambda x: (1 + x).prod() - 1)
    rolling_bench = bench_returns.rolling(60).apply(lambda x: (1 + x).prod() - 1)

    fig_roll = go.Figure()
    fig_roll.add_trace(go.Scatter(
        x=rolling_port.index, y=rolling_port.values,
        name="Portfolio", line=dict(color=COLORS[0], width=1.8),
    ))
    fig_roll.add_trace(go.Scatter(
        x=rolling_bench.index, y=rolling_bench.values,
        name=benchmark, line=dict(color=COLORS[1], width=1.8, dash="dot"),
    ))
    fig_roll.update_layout(yaxis_tickformat=".1%", hovermode="x unified", height=320)
    st.plotly_chart(styled_fig(fig_roll), use_container_width=True)

# ── TAB 2: Risk Analysis ──
with tab_risk:
    col_a, col_b = st.columns(2)

    with col_a:
        dd = compute_drawdown(port_returns)
        fig_dd = go.Figure()
        fig_dd.add_trace(go.Scatter(
            x=dd.index, y=dd.values,
            fill="tozeroy", fillcolor="rgba(255,107,107,0.15)",
            line=dict(color="#ff6b6b", width=1.5),
            name="Drawdown",
        ))
        fig_dd.update_layout(
            title="Underwater (Drawdown) Chart",
            yaxis_tickformat=".1%",
            height=380,
        )
        st.plotly_chart(styled_fig(fig_dd), use_container_width=True)

    with col_b:
        fig_hist = go.Figure()
        fig_hist.add_trace(go.Histogram(
            x=port_returns.values, nbinsx=80,
            marker_color=COLORS[0], opacity=0.7, name="Portfolio",
        ))
        var_line = var_historic(port_returns)
        cvar_line = cvar_historic(port_returns)
        fig_hist.add_vline(x=var_line, line_dash="dash", line_color="#ff6b6b",
                           annotation_text=f"VaR 95%: {var_line:.2%}")
        fig_hist.add_vline(x=cvar_line, line_dash="dash", line_color="#ffd700",
                           annotation_text=f"CVaR: {cvar_line:.2%}")
        fig_hist.update_layout(title="Return Distribution", height=380)
        st.plotly_chart(styled_fig(fig_hist), use_container_width=True)

    # Rolling volatility
    st.markdown("#### Rolling 30-Day Volatility")
    roll_vol_port = port_returns.rolling(30).std() * np.sqrt(252)
    roll_vol_bench = bench_returns.rolling(30).std() * np.sqrt(252)

    fig_rv = go.Figure()
    fig_rv.add_trace(go.Scatter(
        x=roll_vol_port.index, y=roll_vol_port.values,
        name="Portfolio", line=dict(color=COLORS[0], width=1.8),
        fill="tozeroy", fillcolor="rgba(100,255,218,0.06)",
    ))
    fig_rv.add_trace(go.Scatter(
        x=roll_vol_bench.index, y=roll_vol_bench.values,
        name=benchmark, line=dict(color=COLORS[1], width=1.8, dash="dot"),
    ))
    fig_rv.update_layout(yaxis_tickformat=".1%", hovermode="x unified", height=320)
    st.plotly_chart(styled_fig(fig_rv), use_container_width=True)

# ── TAB 3: Correlations ──
with tab_corr:
    asset_returns = prices.pct_change().dropna()

    col1, col2 = st.columns(2)
    with col1:
        corr = asset_returns.corr()
        fig_hm = px.imshow(
            corr,
            text_auto=".2f",
            color_continuous_scale=["#ff6b6b", "#1a1a2e", "#64ffda"],
            zmin=-1, zmax=1,
        )
        fig_hm.update_layout(title="Correlation Matrix", height=450)
        st.plotly_chart(styled_fig(fig_hm), use_container_width=True)

    with col2:
        window = st.slider("Rolling Correlation Window (days)", 20, 120, 60, key="corr_window")
        if len(tickers) >= 2:
            t1, t2 = tickers[0], tickers[1]
            roll_corr = asset_returns[t1].rolling(window).corr(asset_returns[t2])

            fig_rc = go.Figure()
            fig_rc.add_trace(go.Scatter(
                x=roll_corr.index, y=roll_corr.values,
                line=dict(color=COLORS[4], width=1.8),
                name=f"{t1} vs {t2}",
            ))
            fig_rc.add_hline(y=0, line_dash="dash", line_color="rgba(255,255,255,0.2)")
            fig_rc.update_layout(
                title=f"Rolling {window}D Correlation: {t1} vs {t2}",
                yaxis_range=[-1, 1],
                height=450,
            )
            st.plotly_chart(styled_fig(fig_rc), use_container_width=True)
        else:
            st.info("Add at least 2 tickers to see rolling correlation.")

# ── TAB 4: Monte Carlo ──
with tab_mc:
    mc_col1, mc_col2 = st.columns([1, 3])
    with mc_col1:
        n_sims = st.select_slider("Simulations", [100, 500, 1000, 2500, 5000], value=1000)
        horizon = st.slider("Horizon (trading days)", 21, 504, 252)

    with mc_col2:
        with st.spinner("Running Monte Carlo simulation..."):
            sims = monte_carlo_simulation(port_returns, days=horizon, n_sims=n_sims)

        fig_mc = go.Figure()
        # Plot a sample of paths
        sample = min(200, n_sims)
        for i in range(sample):
            fig_mc.add_trace(go.Scatter(
                x=list(range(horizon)),
                y=sims[:, i],
                mode="lines",
                line=dict(color=COLORS[0], width=0.3),
                opacity=0.15,
                showlegend=False,
            ))

        # Percentile bands
        p5 = np.percentile(sims, 5, axis=1)
        p50 = np.percentile(sims, 50, axis=1)
        p95 = np.percentile(sims, 95, axis=1)
        x_range = list(range(horizon))

        fig_mc.add_trace(go.Scatter(x=x_range, y=p5, line=dict(color="#ff6b6b", dash="dash"), name="5th %ile"))
        fig_mc.add_trace(go.Scatter(x=x_range, y=p50, line=dict(color="#ffd700", width=2.5), name="Median"))
        fig_mc.add_trace(go.Scatter(x=x_range, y=p95, line=dict(color="#64ffda", dash="dash"), name="95th %ile"))
        fig_mc.update_layout(
            title=f"Monte Carlo Simulation — {n_sims} Paths, {horizon} Days",
            xaxis_title="Trading Days",
            yaxis_title="Portfolio Value (starting at $1)",
            height=500,
        )
        st.plotly_chart(styled_fig(fig_mc), use_container_width=True)

    # Terminal wealth distribution
    terminal = sims[-1, :]
    mc_m1, mc_m2, mc_m3, mc_m4 = st.columns(4)
    mc_m1.metric("Median Final Value", f"${np.median(terminal):.2f}")
    mc_m2.metric("Mean Final Value", f"${np.mean(terminal):.2f}")
    mc_m3.metric("5th Percentile", f"${np.percentile(terminal, 5):.2f}")
    mc_m4.metric("95th Percentile", f"${np.percentile(terminal, 95):.2f}")

    fig_term = go.Figure()
    fig_term.add_trace(go.Histogram(
        x=terminal, nbinsx=60,
        marker_color=COLORS[0], opacity=0.7,
    ))
    fig_term.add_vline(x=1.0, line_dash="dash", line_color="#ff6b6b",
                       annotation_text="Break Even")
    prob_loss = (terminal < 1.0).mean()
    fig_term.update_layout(
        title=f"Terminal Wealth Distribution — P(loss) = {prob_loss:.1%}",
        xaxis_title="Portfolio Value ($1 start)",
        height=350,
    )
    st.plotly_chart(styled_fig(fig_term), use_container_width=True)

# ── TAB 5: Efficient Frontier ──
with tab_ef:
    if len(tickers) < 2:
        st.warning("Need at least 2 assets to compute the efficient frontier.")
    else:
        asset_rets = prices.pct_change().dropna()

        with st.spinner("Computing efficient frontier (this may take a few seconds)..."):
            ef = cached_efficient_frontier(asset_rets, rf=risk_free)

        # ── Main frontier chart ──
        fig_ef = go.Figure()

        # Random portfolio cloud
        fig_ef.add_trace(go.Scatter(
            x=ef["rand_vols"], y=ef["rand_rets"],
            mode="markers",
            marker=dict(
                size=4, color=ef["rand_sharpes"],
                colorscale=[[0, "#ff6b6b"], [0.5, "#ffd700"], [1, "#64ffda"]],
                colorbar=dict(title="Sharpe", tickfont=dict(color="#8892b0")),
                opacity=0.5,
            ),
            name="Random Portfolios",
            hovertemplate="Vol: %{x:.2%}<br>Return: %{y:.2%}<extra></extra>",
        ))

        # Efficient frontier line
        fig_ef.add_trace(go.Scatter(
            x=ef["frontier_vols"], y=ef["frontier_rets"],
            mode="lines",
            line=dict(color="#e6f1ff", width=3),
            name="Efficient Frontier",
        ))

        # Max Sharpe point
        fig_ef.add_trace(go.Scatter(
            x=[ef["ms_vol"]], y=[ef["ms_ret"]],
            mode="markers",
            marker=dict(size=16, color="#64ffda", symbol="star", line=dict(width=2, color="#0a0a1a")),
            name=f"Max Sharpe ({ef['ms_sharpe']:.2f})",
            hovertemplate=f"Max Sharpe<br>Return: {ef['ms_ret']:.2%}<br>Vol: {ef['ms_vol']:.2%}<extra></extra>",
        ))

        # Min Variance point
        fig_ef.add_trace(go.Scatter(
            x=[ef["mv_vol"]], y=[ef["mv_ret"]],
            mode="markers",
            marker=dict(size=14, color="#ffd700", symbol="diamond", line=dict(width=2, color="#0a0a1a")),
            name=f"Min Variance",
            hovertemplate=f"Min Variance<br>Return: {ef['mv_ret']:.2%}<br>Vol: {ef['mv_vol']:.2%}<extra></extra>",
        ))

        # Current portfolio point
        cur_ret = annualized_return(port_returns)
        cur_vol = annualized_vol(port_returns)
        fig_ef.add_trace(go.Scatter(
            x=[cur_vol], y=[cur_ret],
            mode="markers",
            marker=dict(size=14, color="#f77fbe", symbol="circle", line=dict(width=2, color="#0a0a1a")),
            name="Your Portfolio",
            hovertemplate=f"Your Portfolio<br>Return: {cur_ret:.2%}<br>Vol: {cur_vol:.2%}<extra></extra>",
        ))

        # Capital Market Line
        cml_x = np.linspace(0, max(ef["rand_vols"]) * 0.9, 50)
        cml_y = risk_free + (ef["ms_ret"] - risk_free) / ef["ms_vol"] * cml_x
        fig_ef.add_trace(go.Scatter(
            x=cml_x, y=cml_y,
            mode="lines",
            line=dict(color="rgba(100,255,218,0.3)", width=1.5, dash="dash"),
            name="Capital Market Line",
        ))

        fig_ef.update_layout(
            title="Mean-Variance Efficient Frontier",
            xaxis_title="Annualized Volatility",
            yaxis_title="Annualized Return",
            xaxis_tickformat=".1%",
            yaxis_tickformat=".1%",
            height=550,
            hovermode="closest",
        )
        st.plotly_chart(styled_fig(fig_ef), use_container_width=True)

        # ── Optimal portfolio weights ──
        st.markdown("#### Optimal Portfolio Weights")
        opt_col1, opt_col2 = st.columns(2)

        with opt_col1:
            st.markdown("**⭐ Max Sharpe Portfolio**")
            ms_df = pd.DataFrame({
                "Ticker": ef["tickers"],
                "Weight": [f"{w:.1%}" for w in ef["max_sharpe_w"]],
            })
            ms_df = ms_df[ef["max_sharpe_w"] > 0.005]  # filter near-zero
            st.dataframe(ms_df, hide_index=True, use_container_width=True)
            st.caption(f"Return: {ef['ms_ret']:.2%} · Vol: {ef['ms_vol']:.2%} · Sharpe: {ef['ms_sharpe']:.2f}")

        with opt_col2:
            st.markdown("**💎 Min Variance Portfolio**")
            mv_df = pd.DataFrame({
                "Ticker": ef["tickers"],
                "Weight": [f"{w:.1%}" for w in ef["min_var_w"]],
            })
            mv_df = mv_df[ef["min_var_w"] > 0.005]
            st.dataframe(mv_df, hide_index=True, use_container_width=True)
            st.caption(f"Return: {ef['mv_ret']:.2%} · Vol: {ef['mv_vol']:.2%} · Sharpe: {ef['mv_sharpe']:.2f}")

        # ── Comparison bar chart ──
        comp_df = pd.DataFrame({
            "Ticker": ef["tickers"],
            "Your Portfolio": [weights.get(t, 0) for t in ef["tickers"]],
            "Max Sharpe": ef["max_sharpe_w"],
            "Min Variance": ef["min_var_w"],
        })
        fig_comp = go.Figure()
        fig_comp.add_trace(go.Bar(
            x=comp_df["Ticker"], y=comp_df["Your Portfolio"],
            name="Your Portfolio", marker_color="#f77fbe",
        ))
        fig_comp.add_trace(go.Bar(
            x=comp_df["Ticker"], y=comp_df["Max Sharpe"],
            name="Max Sharpe", marker_color="#64ffda",
        ))
        fig_comp.add_trace(go.Bar(
            x=comp_df["Ticker"], y=comp_df["Min Variance"],
            name="Min Variance", marker_color="#ffd700",
        ))
        fig_comp.update_layout(
            title="Weight Comparison: Your Portfolio vs Optimal",
            barmode="group",
            yaxis_tickformat=".0%",
            height=380,
        )
        st.plotly_chart(styled_fig(fig_comp), use_container_width=True)


# ── TAB 6: Factor Analysis ──
with tab_factor:
    st.markdown("""
    > **Fama-French 3-Factor Model** decomposes your portfolio's returns into exposure to
    > the overall market (Mkt-RF), company size (SMB — small minus big), and
    > value vs growth (HML — high minus low book-to-market). Alpha is what's left over —
    > the return not explained by these systematic factors.
    """)

    with st.spinner("Fetching factor data & running regression..."):
        ff_factors = fetch_ff_factors(start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d"))
        factor_results = run_factor_regression(port_returns, ff_factors)

    # ── Key metrics ──
    fr = factor_results
    fm1, fm2, fm3, fm4 = st.columns(4)
    fm1.metric("Annualized Alpha", f"{fr['annualized_alpha']:.2%}")
    fm2.metric("R-Squared", f"{fr['r_squared']:.3f}")
    fm3.metric("Market Beta (β)", f"{fr['coefficients']['Mkt-RF (β_mkt)']:.3f}")
    fm4.metric("Adj. R-Squared", f"{fr['adj_r_squared']:.3f}")

    # ── Regression results table ──
    st.markdown("#### Regression Coefficients")
    reg_df = pd.DataFrame({
        "Factor": list(fr["coefficients"].keys()),
        "Coefficient": [f"{v:.6f}" for v in fr["coefficients"].values()],
        "t-Statistic": [f"{v:.3f}" for v in fr["t_stats"].values()],
        "p-Value": [f"{v:.4f}" for v in fr["p_values"].values()],
        "Significant": ["✅" if p < 0.05 else "❌" for p in fr["p_values"].values()],
    })
    st.dataframe(reg_df, hide_index=True, use_container_width=True)

    fa_col1, fa_col2 = st.columns(2)

    with fa_col1:
        # Factor exposure bar chart
        betas = {k: v for k, v in fr["coefficients"].items() if "Alpha" not in k}
        fig_betas = go.Figure()
        beta_colors = ["#64ffda", "#f77fbe", "#ffd700"]
        for i, (name, val) in enumerate(betas.items()):
            short_name = name.split("(")[0].strip()
            fig_betas.add_trace(go.Bar(
                x=[short_name], y=[val],
                name=short_name,
                marker_color=beta_colors[i],
                text=[f"{val:.3f}"],
                textposition="outside",
                textfont=dict(color="#ccd6f6"),
            ))
        fig_betas.update_layout(
            title="Factor Exposures (Betas)",
            yaxis_title="Beta Coefficient",
            showlegend=False,
            height=400,
        )
        fig_betas.add_hline(y=0, line_dash="dash", line_color="rgba(255,255,255,0.2)")
        st.plotly_chart(styled_fig(fig_betas), use_container_width=True)

    with fa_col2:
        # Return attribution waterfall
        contribs = fr["contributions"]
        fig_attr = go.Figure(go.Waterfall(
            x=list(contribs.keys()) + ["Total"],
            y=list(contribs.values()) + [sum(contribs.values())],
            measure=["relative"] * len(contribs) + ["total"],
            connector=dict(line=dict(color="rgba(255,255,255,0.1)")),
            increasing=dict(marker=dict(color="#64ffda")),
            decreasing=dict(marker=dict(color="#ff6b6b")),
            totals=dict(marker=dict(color="#82aaff")),
            textposition="outside",
            text=[f"{v:.2%}" for v in contribs.values()] + [f"{sum(contribs.values()):.2%}"],
            textfont=dict(color="#ccd6f6"),
        ))
        fig_attr.update_layout(
            title="Annualized Return Attribution",
            yaxis_tickformat=".1%",
            height=400,
            showlegend=False,
        )
        st.plotly_chart(styled_fig(fig_attr), use_container_width=True)

    # ── Residuals analysis ──
    st.markdown("#### Residual Analysis")
    res_col1, res_col2 = st.columns(2)

    with res_col1:
        residuals = fr["residuals"]
        fig_resid = go.Figure()
        fig_resid.add_trace(go.Scatter(
            x=list(range(len(residuals))), y=residuals,
            mode="markers",
            marker=dict(size=3, color="#64ffda", opacity=0.5),
            name="Residuals",
        ))
        fig_resid.add_hline(y=0, line_color="rgba(255,255,255,0.3)")
        fig_resid.add_hline(y=residuals.std() * 2, line_dash="dash", line_color="#ff6b6b", opacity=0.5)
        fig_resid.add_hline(y=-residuals.std() * 2, line_dash="dash", line_color="#ff6b6b", opacity=0.5)
        fig_resid.update_layout(title="Residuals vs Index", height=350, xaxis_title="Observation")
        st.plotly_chart(styled_fig(fig_resid), use_container_width=True)

    with res_col2:
        fig_resid_hist = go.Figure()
        fig_resid_hist.add_trace(go.Histogram(
            x=residuals, nbinsx=60,
            marker_color="#c792ea", opacity=0.7,
        ))
        fig_resid_hist.update_layout(title="Residual Distribution", height=350)
        st.plotly_chart(styled_fig(fig_resid_hist), use_container_width=True)

    # Interpretation helper
    alpha_val = fr["annualized_alpha"]
    mkt_beta = fr["coefficients"]["Mkt-RF (β_mkt)"]
    smb_beta = fr["coefficients"]["SMB (β_smb)"]
    hml_beta = fr["coefficients"]["HML (β_hml)"]
    r2 = fr["r_squared"]

    interpretation = []
    if alpha_val > 0.01:
        interpretation.append(f"🟢 **Positive alpha** ({alpha_val:.2%} annualized) — the portfolio generated excess returns beyond factor exposures.")
    elif alpha_val < -0.01:
        interpretation.append(f"🔴 **Negative alpha** ({alpha_val:.2%} annualized) — the portfolio underperformed relative to its factor exposures.")
    else:
        interpretation.append(f"⚪ **Near-zero alpha** ({alpha_val:.2%}) — returns are well-explained by factor exposures.")

    if mkt_beta > 1.05:
        interpretation.append(f"📈 **Aggressive market beta** ({mkt_beta:.2f}) — more volatile than the market.")
    elif mkt_beta < 0.95:
        interpretation.append(f"🛡️ **Defensive market beta** ({mkt_beta:.2f}) — less volatile than the market.")

    if smb_beta > 0.1:
        interpretation.append("📊 **Small-cap tilt** — portfolio tilts toward smaller companies.")
    elif smb_beta < -0.1:
        interpretation.append("🏢 **Large-cap tilt** — portfolio tilts toward larger companies.")

    if hml_beta > 0.1:
        interpretation.append("💰 **Value tilt** — portfolio tilts toward value stocks.")
    elif hml_beta < -0.1:
        interpretation.append("🚀 **Growth tilt** — portfolio tilts toward growth stocks.")

    interpretation.append(f"📐 **R² = {r2:.1%}** — the three factors explain {r2:.1%} of portfolio return variation.")

    st.markdown("#### Interpretation")
    for line in interpretation:
        st.markdown(line)


# ──────────────────────────────────────────────
# Footer
# ──────────────────────────────────────────────
st.markdown("---")
st.caption(
    "Built with Streamlit • Data from Yahoo Finance"
)
