# 📊 Portfolio Analytics Dashboard

A Streamlit-powered portfolio analysis tool.

## Features

| Tab | What it does |
|-----|-------------|
| **Performance** | Cumulative returns vs benchmark, allocation pie chart, rolling 60-day returns |
| **Risk Analysis** | Drawdown chart, return distribution with VaR/CVaR markers, rolling volatility |
| **Correlations** | Correlation heatmap across holdings, rolling pairwise correlation |
| **Monte Carlo** | Forward simulation with configurable paths & horizon, terminal wealth distribution |
| **Efficient Frontier** | Mean-variance optimization, Max Sharpe & Min Variance portfolios, Capital Market Line |
| **Factor Analysis** | Fama-French 3-factor regression, beta exposures, return attribution waterfall, residual diagnostics |

### Key Metrics (top bar)
- Annualized Return & Volatility
- Sharpe Ratio / Sortino Ratio
- Max Drawdown
- Daily Value-at-Risk (95%)

## Quick Start

```bash
# 1. Clone and enter the project
git clone <your-repo-url>
cd portfolio-dashboard

# 2. Create a virtual environment (recommended)
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
streamlit run app.py

# 5. Run tests
pytest test_analytics.py -v
```

The app opens at `http://localhost:8501`.

## How to Use

1. **Pick a preset** or enter custom tickers in the sidebar
2. **Adjust weights** (should sum to 100%)
3. **Set parameters**: benchmark, lookback period, risk-free rate
4. **Click "Analyze Portfolio"** and explore the six tabs

## Project Structure

```
portfolio-dashboard/
├── app.py              # Streamlit UI — layout, charts, interactivity
├── analytics.py        # Pure analytics functions (no Streamlit dependency)
├── test_analytics.py   # 25 unit tests (pytest)
├── requirements.txt    # Python dependencies
├── .gitignore          # Git ignore rules
└── README.md           # This file
```

### Architecture Decision: Separating `analytics.py` from `app.py`

The analytics functions live in their own module so they can be:
- **Tested** without mocking Streamlit
- **Reused** in notebooks, scripts, or other apps
- **Reviewed** independently from UI code

## Streamlit Patterns Demonstrated

- **`st.cache_data`** — caches Yahoo Finance API calls and expensive computations (EF optimization)
- **`st.session_state`** — persists portfolio data across interactions
- **Sidebar layout** — input controls separated from main content
- **Tabs** — organize a complex dashboard into logical sections
- **Plotly integration** — interactive, dark-themed financial charts
- **Custom CSS** — professional styling via `st.markdown` with HTML
- **Spinner** — loading feedback during data fetch & simulation
- **Metrics** — KPI cards with `st.metric`
- **Responsive columns** — `st.columns` for side-by-side layout

## Finance Concepts Covered

| Concept | Where | Why it matters |
|---------|-------|----------------|
| Portfolio construction & weighting | Sidebar | Fundamental to any investment process |
| Cumulative & rolling returns | Performance tab | How did the portfolio actually perform? |
| Sharpe & Sortino ratios | KPI row | Risk-adjusted return measurement |
| Maximum drawdown | Risk tab | Worst peak-to-trough loss |
| Value-at-Risk & Conditional VaR | Risk tab | Tail risk quantification |
| Correlation analysis | Correlations tab | Diversification effectiveness |
| Monte Carlo simulation | Monte Carlo tab | Forward-looking probabilistic modeling |
| Mean-variance optimization | Efficient Frontier tab | Modern Portfolio Theory (Markowitz) |
| Fama-French 3-Factor model | Factor Analysis tab | Where do returns come from? |
| Alpha & beta decomposition | Factor Analysis tab | Skill vs systematic exposure |

## Testing

```bash
# Run all tests
pytest test_analytics.py -v

# Run a specific test class
pytest test_analytics.py::TestSharpeRatio -v
```

The test suite validates all core analytics functions against known values and edge cases, including: return calculations, risk metrics (Sharpe, Sortino, VaR, CVaR, drawdown), portfolio construction, and optimization helpers.

## Ideas for Extension

- **Efficient Frontier with short selling** — remove the (0, 1) bounds constraint
- **Black-Litterman model** — incorporate subjective views into optimization
- **Live factor data** — use Ken French's data library instead of ETF proxies
- **PDF export** — generate a one-pager report with `fpdf2`
- **Multi-period rebalancing** — simulate periodic rebalancing strategies
- **Database backend** — store portfolio snapshots in SQLite for tracking
- **Authentication** — add `streamlit-authenticator` for multi-user support

## Tech Stack

- **Streamlit** — UI framework
- **yfinance** — market data
- **Pandas / NumPy** — data manipulation & numerical computing
- **SciPy** — portfolio optimization (SLSQP)
- **statsmodels** — OLS regression for factor analysis
- **Plotly** — interactive charting
- **pytest** — unit testing

---


